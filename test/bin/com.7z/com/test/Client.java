package com.test;

public class Client {
	
	public static void main(String[] args) {
		LoginForm lf = new LoginForm();
	}
}
